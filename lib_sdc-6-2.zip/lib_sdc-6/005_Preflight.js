/**
 * @file 005_Preflight.gs
 * Common pre-execution checks for any flow that serializes config and hands it to Workato.
 *
 * Public:
 *   Preflight.run(ss, config, options) → { customerSheet, integrationAccountEmail, [<every CUSTOMER_FIELDS key>] }
 *
 * Throw-on-failure contract: every check raises a user-facing Error on the first failure. Orchestrators wrap
 * the call in a single try/catch and own UI/logging.
 *
 * Checks (in order):
 *   1. Schema sanity — already enforced by Config.build; preflight does not re-check.
 *   2. All CONNECTOR_SHEETS present in the workbook.
 *   2b. Sheet layouts match the library's layout constants and PK columns (Layout.verify, schema 1.7+).
 *   3. The customer sheet (per config.sheets.customer) is present.
 *   4. The router base URL and token are configured (Webhook._requireRouter).
 *   5. config.sharing.integrationAccountEmail is present and email-shaped.
 *   6. (requireCustomerData only) 1_customer, registry-driven: every required field located and non-blank
 *      (5a/5b), every field with `options` holds one of them (5b'), then the hand-written shape checks for the
 *      fields that have one (5c expected date, 5d logo link, 5e reminder cadence). Schema 1.10: the seed-data
 *      checks (5f/5g) are gone with the fields.
 */

var Preflight = {};

/**
 * @param {Spreadsheet} ss
 * @param {Object}      config
 * @param {Object}      options
 * @param {boolean}     [options.requireCustomerData=false] - When true, also pull and validate customer fields from 1_customer.
 * @returns {Object} { customerSheet, integrationAccountEmail } plus, when requireCustomerData is true, one property per
 *                   CUSTOMER_FIELDS key (schema 1.10: clientName, analystEmail, targetVms, reminderDays [flattened to
 *                   number[]], expectedDate, variantCount, customerLogoUrl), coerced per the registry type.
 * @throws  Error with a user-facing message on any check failure.
 */
Preflight.run = function (ss, config, options) {
  if (!ss) throw new Error('Preflight.run: ss is required.');
  if (!config) throw new Error('Preflight.run: config is required.');
  if (!options) throw new Error('Preflight.run: options is required.');

  // 1. All connector sheets present
  var missing = [];
  CONNECTOR_SHEETS_ORDER.forEach(function (name) {
    if (!ss.getSheetByName(name)) missing.push(name);
  });
  if (missing.length > 0) {
    throw new Error(
      'Missing required sheets: ' + missing.join(', ') + '. ' +
      'These sheets are part of the workbook schema (v' + config.schemaVersion + ') ' +
      'and must be present for the SDC platform to read the configuration.'
    );
  }

  // 1b. Sheet layouts match the library's constants (header anchors + PK columns). Every reader in Drive, Variant and
  //     PrimaryKey addresses columns by fixed index, so a shifted column must fail here, by name, rather than serialize
  //     the wrong cells. A stray PK column on a cast sheet is the schema-1.7 migration's job, and the message says so.
  var layout = Layout.verify(ss);
  if (!layout.ok) {
    throw new Error(
      'Workbook layout does not match schema v' + SDC_SCHEMA_VERSION + ':\n  - ' + layout.problems.join('\n  - ') +
      '\nIf the workbook has not been migrated, run "Migrate workbook schema" from the menu and retry. ' +
      'Otherwise a header cell was edited or a column was moved; restore it to the text shown.'
    );
  }

  // 2. Customer sheet present (defensive — already covered by check 1, but the error message here is more specific to the customer-data flow.)
  var customerSheet = ss.getSheetByName(config.sheets.customer);
  if (!customerSheet) {
    throw new Error(
      'Sheet "' + config.sheets.customer + '" not found. ' +
      'This is the workbook\'s customer-information tab; check that it has not been ' +
      'renamed and that _developer_settings → sheets.customer matches.'
    );
  }

  // 3. Router configured (base URL + token). Same check Webhook.call makes; failing here gives the analyst the
  //    message before any Drive writes happen.
  Webhook._requireRouter(config);

  // 4. Workato OAuth account email present and well-formed
  var integrationAccountEmail = config.sharing.integrationAccountEmail;
  if (!integrationAccountEmail || !Util.isValidEmailShape(integrationAccountEmail)) {
    throw new Error(
      'Workato OAuth account email is missing or malformed. ' +
      'Check _developer_settings → sharing.integrationAccountEmail. ' +
      'Workato cannot read the config file without this share.'
    );
  }

  // 5. Customer data fields (provision path only). Reads go through Customer.read (named ranges with label fallback + self-heal).
  // Required-ness and coercion are driven by the CUSTOMER_FIELDS registry.
  var customerData = {};
  if (options.requireCustomerData) {
    var read = Customer.read(ss, config);
    customerData = read.values;

    var defsByKey = {};
    CUSTOMER_FIELDS.forEach(function (d) { defsByKey[d.key] = d; });

    // 5a. Fields that could not be LOCATED at all (named range AND label both missing). Distinct from "located but blank".
    var lost = read.unresolved.filter(function (u) { return defsByKey[u.key].required; });
    if (lost.length > 0) {
      throw new Error(
        'Could not locate these fields on the ' + config.sheets.customer + ' tab: ' +
        lost.map(function (u) { return '"' + u.label + '"'; }).join(', ') + '. ' +
        'Each field is read through a workbook named range (' +
        lost.map(function (u) { return u.rangeName; }).join(', ') + ') with the printed ' +
        'question text as a fallback; neither was found. This usually means the ' +
        'question wording was edited and the named range was also removed. Restore ' +
        'the wording, or recreate the named range via Data \u2192 Named ranges, then retry.'
      );
    }

    // 5b. Required-but-blank (registry-driven)
    var missingFields = [];
    CUSTOMER_FIELDS.forEach(function (def) {
      if (!def.required) return;
      var v = customerData[def.key];
      var blank;
      switch (def.type) {
        case 'intList':
          blank = v.ints.length === 0 && v.invalid.length === 0;
          break;
        case 'date': {
          var rd = read.raw[def.key];
          blank = rd === null || rd === undefined || rd === '';
          break;
        }
        case 'bool':
          blank = false;  // booleans coerce blank -> false; never "missing"
          break;
        default:
          blank = v === null;
      }
      if (blank) missingFields.push(def.friendly);
    });
    if (missingFields.length > 0) {
      throw new Error(
        'Required customer fields missing in the ' + config.sheets.customer + ' tab: ' +
        missingFields.join(', ') + '. ' +
        'All required fields must be filled in before the configuration can be sent to Workato.'
      );
    }

    // 5b'. Pick lists (registry-driven). A non-blank value on a field with `options` must be one of them; the value
    //      is replaced by the list's canonical spelling so the wire never carries "vndly" next to "VNDLY".
    CUSTOMER_FIELDS.forEach(function (def) {
      if (!def.options) return;
      var v = customerData[def.key];
      if (v === null || v === undefined) return;             // blank: 5b's concern, already passed if optional
      var canonical = Customer.matchOption(def, v);
      if (canonical === null) {
        throw new Error(
          'The "' + def.label + '" value "' + v + '" in the ' + config.sheets.customer +
          ' tab is not one of the allowed choices: ' + def.options.join(', ') + '. ' +
          'Pick it from the dropdown (run "Migrate workbook schema" if the cell has none).'
        );
      }
      customerData[def.key] = canonical;
    });

    // 5c. Expected date (present but not a usable date).
    var rawExpectedDate = read.raw.expectedDate;
    var rawDateBlank = rawExpectedDate === null || rawExpectedDate === undefined || rawExpectedDate === '';
    if (!rawDateBlank && customerData.expectedDate === null) {
      throw new Error(
        'The "' + Labels.expectedDate + '" value in the ' + config.sheets.customer +
        ' tab is not a recognizable date. Enter it via the date picker (yyyy-mm-dd). ' +
        'Text in another format, or a number formatted to look like a date, cannot be used.'
      );
    }

    // 5d. Customer logo public link (optional; shape only). Preflight will not fetch the URL - a dead link is the
    //     analyst's to notice on the portal - but it will catch a Drive *share* link pasted where an image URL
    //     belongs, which is the one mistake that is cheap to make and expensive to find later.
    var logo = customerData.customerLogoUrl;   // string | null (trimmed by Customer._coerce)
    if (logo !== null) {
      if (!/^https?:\/\/\S+$/i.test(logo)) {
        throw new Error(
          'The "' + Labels.customerLogoUrl + '" value in the ' + config.sheets.customer +
          ' tab is not a web address. Enter the full public URL of the logo image (starting with https://), ' +
          'or leave the field blank.'
        );
      }
      if (/^https?:\/\/(drive|docs)\.google\.com\/(file\/d\/|open\?)/i.test(logo)) {
        throw new Error(
          'The "' + Labels.customerLogoUrl + '" value is a Google Drive share link, which opens a viewer page ' +
          'rather than the image. Use a direct image URL (one that shows only the picture when opened in a browser), ' +
          'or leave the field blank.'
        );
      }
    }

    // 5e. Reminder cadence (reject bad tokens, then flatten to the int array that Payload.provision ships as reminder_days).
    var cadence = customerData.reminderDays;   // { ints, invalid } from parseIntList
    if (cadence.invalid.length > 0) {
      throw new Error(
        'The "' + Labels.reminderDays + '" value contains entries that are not ' +
        'positive whole numbers: ' + cadence.invalid.join(', ') + '. ' +
        'Enter a comma-separated list of day counts, e.g. "7, 14, 21".'
      );
    }
    customerData.reminderDays = cadence.ints;
    // Optional — enable if semantics stay "offsets from the initial request":
    // for (var d = 1; d < customerData.reminderDays.length; d++) {
    //   if (customerData.reminderDays[d] <= customerData.reminderDays[d - 1]) {
    //     throw new Error('Reminder days must be strictly increasing offsets from ' +
    //                     'the initial request; got: ' + cadence.ints.join(', ') + '.');
    //   }
    // }
  }

  return Object.assign({
    customerSheet: customerSheet,
    integrationAccountEmail: integrationAccountEmail
  }, customerData);
};
