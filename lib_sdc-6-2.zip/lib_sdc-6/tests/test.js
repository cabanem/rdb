'use strict';
const assert = require('assert');
const { ctx, Spreadsheet } = require('./harness.js');
const vm = require('vm');
const run = (code) => vm.runInContext(code, ctx);
// vm results live in another realm; JSON-roundtrip for structural comparisons
const J = (code) => JSON.parse(JSON.stringify(run(code)));
const snap = (ss) => JSON.stringify(ss.sheets['1_customer'].rows) +
  JSON.stringify(Object.fromEntries(Object.entries(ss.named).map(([k, v]) => [k, { sheet: v.sheet.name, row: v.row, col: v.col, broken: !!v.broken }])));

let passed = 0;
function test(name, fn) { fn(); passed++; console.log('  ok  ' + name); }

// ---------------------------------------------------------------- fixture: a schema-1.8 workbook (v0.9.9 layout)
// 1_customer: A blank, B = #, C = label, D = value, E = required marker. Rows 1-3 are a banner.
function customerSheet() {
  const fields = [
    ['Customer name',                 'Sony',                 '*'],
    ['Analyst email address',         'emily@example.com',    '*'],
    ['Application name',              'Sony contractors',     '*'],
    ['Target VMS',                    'VNDLY',                ''],
    ['Drive folder ID',               '1abcFOLDER',           '*'],
    ['Reminder cadence',              '7, 14, 21',            '*'],
    ['Last day for data submission',  new Date('2026-12-15'), '*'],
    ['Expected completion date',      new Date('2026-12-31'), '*'],
    ['Portal instructions',           'Welcome to the portal', ''],
    ['Kick off email instructions',   'Hello supplier',       ''],
    ['Incumbent data flag',           'yes',                  ''],
    ['Seed data Drive file ID',       '1seedFILE',            ''],
    ['Seed data sheet name',          'People - Contractors', ''],
    ['Seed data index key',           'Worker ID',            ''],
    ['Seed data header row',          5,                      ''],
    ['Seed data first data row',      7,                      ''],
    ['Variant count',                 2,                      '']
  ];
  const rows = [['', 'Customer information', '', '', ''], ['', '', '', '', ''], ['', '#', 'Question', 'Answer', 'Req.']];
  fields.forEach((f, i) => rows.push(['', i + 1, f[0], f[1], f[2]]));
  rows.push(['', '', '', '', '']);
  rows.push(['', '', 'Notes: fill in every starred row before starting.', '', '']);
  return rows;
}
function devSettings(schema) {
  return [
    ['description', 'category', 'key', 'value'],
    ['', 'meta', 'schema_version', schema],
    ['', 'sharing', 'integrationAccountEmail', 'workato@example.com'],
    ['', 'webhook', 'apiPlatformToken', 'OLD-TOKEN'],
    ['', 'router', 'baseUrl', 'https://router.example/workspace_lifecycles-v1'],
    ['', 'router', 'apiToken', 'ROUTER-TOKEN'],
    ['', 'meta', 'workspace_key', 'sdc-test']
  ];
}
function workbook(schema) {
  const ss = new Spreadsheet({ '1_customer': customerSheet(), '_developer_settings': devSettings(schema), '_script_logs': [[]] });
  // Named ranges as a migrated-to-1.8 workbook carries them (value cell = column D of the label's row).
  const labelRow = (label) => ss.sheets['1_customer'].rows.findIndex(r => r[2] === label) + 1;
  const anchors = {
    cfg_customer_name: 'Customer name', cfg_analyst_email: 'Analyst email address', cfg_application_name: 'Application name',
    cfg_target_vms: 'Target VMS', cfg_output_folder_id: 'Drive folder ID', cfg_reminder_days: 'Reminder cadence',
    cfg_last_day_for_submission: 'Last day for data submission', cfg_expected_date: 'Expected completion date',
    cfg_supplier_instructions: 'Portal instructions', cfg_kickoff_email_body: 'Kick off email instructions',
    cfg_has_seed_data: 'Incumbent data flag', cfg_seed_data_drive_id: 'Seed data Drive file ID',
    cfg_seed_data_sheet_name: 'Seed data sheet name', cfg_seed_data_index_key: 'Seed data index key',
    cfg_seed_data_header_row: 'Seed data header row', cfg_seed_data_first_data_row: 'Seed data first data row',
    cfg_variant_count: 'Variant count'
  };
  for (const [name, label] of Object.entries(anchors)) ss.setNamedRange(name, ss.sheets['1_customer'].getRange(labelRow(label), 4));
  return ss;
}
const labels = (ss) => ss.sheets['1_customer'].rows.map(r => r[2]).filter(l => l && l !== 'Question' && !/^Notes/.test(l));
const numbers = (ss) => ss.sheets['1_customer'].rows.map(r => r[1]).filter(n => typeof n === 'number');

// ---------------------------------------------------------------- 1. load-time state
test('library loads; versions 1.11.0 / 12.0 / 1.10; Payload exists; Preflight defined once', () => {
  assert.deepStrictEqual(J('[Version.LIBRARY, Version.PAYLOAD, Version.SCHEMA]'), ['1.11.0', '12.0', '1.10']);
  assert.strictEqual(typeof run('Payload.provision'), 'function');
  assert.deepStrictEqual(J('CUSTOMER_FIELDS.map(function(d){return d.key})'),
    ['clientName', 'analystEmail', 'targetVms', 'reminderDays', 'expectedDate', 'variantCount', 'customerLogoUrl']);
  assert.ok(J('CUSTOMER_FIELDS.every(function(d){return d.required===true})'), 'all seven required');
  assert.deepStrictEqual(J('CUSTOMER_FIELDS.filter(function(d){return d.options}).map(function(d){return [d.key, d.options]})'),
    [['targetVms', ['Fieldglass', 'VNDLY', 'Beeline']], ['variantCount', [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]]]);
  assert.deepStrictEqual(J('MIGRATION_CHAIN.map(function(s){return s.from+">"+s.to})').slice(-3), ['1.7>1.8', '1.8>1.9', '1.9>1.10']);
});

// ---------------------------------------------------------------- 2. the chain 1.8 -> 1.10
test('1.8 -> 1.10: three steps... two steps apply; 1_customer converges on the seven attributes', () => {
  const ss = workbook('1.8');
  ctx.ss = ss;
  const r = run('Migrations.run(ss)');
  assert.strictEqual(r.ok, true, JSON.stringify(r, null, 1));
  assert.deepStrictEqual(JSON.parse(JSON.stringify(r.data.applied.map(a => a.from + '>' + a.to))), ['1.8>1.9', '1.9>1.10']);
  assert.deepStrictEqual(labels(ss), [
    'Customer name', 'Analyst email address', 'Target VMS', 'Reminder cadence', 'Expected completion date',
    'Variant count', 'Customer logo public link']);
  assert.deepStrictEqual(numbers(ss), [1, 2, 3, 4, 5, 6, 7]);
  // named ranges: survivors re-anchored on the right rows, retired ones gone, logo anchored on D of its row
  const sheet = ss.sheets['1_customer'];
  for (const d of run('CUSTOMER_FIELDS')) {
    const nr = ss.named[d.rangeName];
    assert.ok(nr && !nr.broken, d.rangeName + ' missing/broken');
    assert.strictEqual(sheet.rows[nr.row - 1][2], d.label, d.rangeName + ' anchored on wrong row');
    assert.strictEqual(nr.col, 4);
  }
  for (const gone of ['cfg_application_name', 'cfg_output_folder_id', 'cfg_last_day_for_submission', 'cfg_has_seed_data', 'cfg_kickoff_email_body'])
    assert.strictEqual(ss.named[gone], undefined, gone + ' should be removed');
  // values survived the row shuffle
  assert.strictEqual(ss.getRangeByName('cfg_variant_count').getValue(), 2);
  assert.strictEqual(ss.getRangeByName('cfg_customer_name').getValue(), 'Sony');
  assert.strictEqual(ss.getRangeByName('cfg_customer_logo_url').getValue(), '');
  // the trailing notes row is still below the block, logo row directly after Variant count
  const logoRow = ss.named.cfg_customer_logo_url.row;
  assert.strictEqual(sheet.rows[logoRow - 2][2], 'Variant count');
  assert.ok(/^Notes/.test(sheet.rows[logoRow + 1][2]), 'notes row should follow the block');
  // schema_version stamped as TEXT, reads back '1.10' not 1.1
  const dev = ss.sheets['_developer_settings'];
  const row = dev.rows.find(r => r[1] === 'meta' && r[2] === 'schema_version');
  assert.strictEqual(row[3], '1.10');
  assert.strictEqual(run('Migrations.currentWorkbookVersion(ss)'), '1.10');
  assert.strictEqual(run('Migrations.isMigrationNeeded(ss)'), false);
});

test('the text-stamp guard matters: a naive setValue would have produced 1.1', () => {
  const ss = workbook('1.9');
  ss.sheets['_developer_settings'].getRange(2, 4).setValue('1.10');   // automatic format
  assert.strictEqual(ss.sheets['_developer_settings'].rows[1][3], 1.1);
});

test('1.9 -> 1.10 is idempotent (second run is a no-op with notes, no duplicate logo row)', () => {
  const ss = workbook('1.8'); ctx.ss = ss;
  assert.strictEqual(run('Migrations.run(ss)').ok, true);
  const before = snap(ss);
  const step = run('MIGRATION_CHAIN[MIGRATION_CHAIN.length-1]');
  const out = step.run(ss);
  assert.strictEqual(out.changed.length, 0, out.changed.join('\n'));
  assert.ok(out.notes.some(n => /already present/.test(n)));
  assert.strictEqual(snap(ss), before);
});

test('1.9 -> 1.10 falls back to label text when the named ranges are missing', () => {
  const ss = workbook('1.8'); ctx.ss = ss;
  assert.strictEqual(run('Migrations.run(ss)').ok, true);
  // simulate a workbook whose analyst deleted the three retired ranges but left the rows, and lost the logo range
  const ss2 = workbook('1.9');
  for (const n of Object.keys(ss2.named)) if (!/customer_name|analyst_email|target_vms|reminder_days|expected_date|variant_count/.test(n)) delete ss2.named[n];
  // remove the seed/messaging rows by hand to mimic a 1.9 workbook
  const sheet = ss2.sheets['1_customer'];
  for (const l of ['Portal instructions', 'Kick off email instructions', 'Incumbent data flag', 'Seed data Drive file ID', 'Seed data sheet name', 'Seed data index key', 'Seed data header row', 'Seed data first data row'])
    sheet.deleteRow(sheet.rows.findIndex(r => r[2] === l) + 1);
  ctx.ss = ss2;
  const r = run('Migrations.run(ss)');
  assert.strictEqual(r.ok, true, JSON.stringify(r, null, 1));
  assert.deepStrictEqual(labels(ss2), ['Customer name', 'Analyst email address', 'Target VMS', 'Reminder cadence', 'Expected completion date', 'Variant count', 'Customer logo public link']);
  assert.deepStrictEqual(numbers(ss2), [1, 2, 3, 4, 5, 6, 7]);
});

test('1.7 -> 1.8 no longer throws ReferenceError (seedToken) and seeds router.apiToken from the old token', () => {
  const ss = new Spreadsheet({ '_developer_settings': [['d', 'category', 'key', 'value'], ['', 'meta', 'schema_version', '1.7'], ['', 'webhook', 'apiPlatformToken', 'OLD-TOKEN']], '1_customer': customerSheet(), '_script_logs': [[]] });
  const step = run('MIGRATION_CHAIN.filter(function(s){return s.from==="1.7"})[0]');
  const out = step.run(ss);
  const rows = ss.sheets['_developer_settings'].rows;
  const tok = rows.find(r => r[1] === 'router' && r[2] === 'apiToken');
  assert.strictEqual(tok[3], 'OLD-TOKEN');
  assert.ok(out.notes.some(n => /seeded from webhook\.apiPlatformToken/.test(n)));
});

// ---------------------------------------------------------------- 3. reads, preflight, payload on the migrated workbook
test('Customer.read / serialize on a migrated workbook; Preflight 5 passes; Payload.provision is the 12.0 shape', () => {
  const ss = workbook('1.8'); ctx.ss = ss;
  assert.strictEqual(run('Migrations.run(ss)').ok, true);
  ss.getRangeByName('cfg_customer_logo_url').setValue('https://cdn.example.com/sony/logo.png');
  run('var config = Config.build(ss);');
  const ser = J('Customer.serialize(ss, config)');
  assert.deepStrictEqual(ser.unresolved, []);
  assert.deepStrictEqual(ser.values, {
    clientName: 'Sony', analystEmail: 'emily@example.com', targetVms: 'VNDLY', reminderDays: [7, 14, 21],
    expectedDate: '2026-12-31', variantCount: 2, customerLogoUrl: 'https://cdn.example.com/sony/logo.png'
  });
  // Preflight: skip the sheet-presence / layout checks (fixture has only 1_customer) by stubbing those two calls
  run('Layout.verify = function(){ return {ok:true, problems:[]}; };');
  run('var _order = CONNECTOR_SHEETS_ORDER; CONNECTOR_SHEETS_ORDER = [];');
  const pf = run('Preflight.run(ss, config, { requireCustomerData: true })');
  assert.deepStrictEqual(JSON.parse(JSON.stringify(pf.reminderDays)), [7, 14, 21]);
  assert.strictEqual(pf.customerLogoUrl, 'https://cdn.example.com/sony/logo.png');
  assert.strictEqual(pf.applicationName, undefined);
  ctx.pf = pf;
  const body = run(`Payload.provision({
    correlationId: 'c1', clientName: pf.clientName, analystEmail: pf.analystEmail, expectedDate: pf.expectedDate,
    reminderDays: pf.reminderDays, targetVms: pf.targetVms, customerLogoUrl: pf.customerLogoUrl,
    configFileId: ss.getId(), configJsonFileId: 'J1', configFingerprint: 'abc', templateFileIds: ['V1','V2'],
    isInitial: false, spreadsheetId: ss.getId() })`);
  assert.deepStrictEqual(Object.keys(body).sort(), [
    'analyst_email', 'client_name', 'config_file_id', 'config_fingerprint', 'correlation_id', 'customer_logo_url',
    'drive_id_config_json', 'expected_date', 'is_initial', 'reminder_days', 'spreadsheet_id', 'target_vms',
    'template_file_ids', 'timestamp']);
  assert.strictEqual(body.is_initial, false);
  assert.strictEqual(body.expected_date, '2026-12-31');
  for (const gone of ['application_name', 'output_drive_folder_id', 'last_day_for_submission', 'has_seeded_data']) assert.ok(!(gone in body), gone);
});

test('Preflight: blank logo is now a named required-field error; non-URL and Drive share links rejected by name', () => {
  const ss = workbook('1.8'); ctx.ss = ss;
  run('Migrations.run(ss)'); run('var config = Config.build(ss);');
  run('Layout.verify = function(){ return {ok:true, problems:[]}; }; CONNECTOR_SHEETS_ORDER = [];');
  assert.throws(() => run('Preflight.run(ss, config, { requireCustomerData: true })'), /missing in the 1_customer tab: Customer logo public link\./);
  ss.getRangeByName('cfg_customer_logo_url').setValue('sony logo.png');
  assert.throws(() => run('Preflight.run(ss, config, { requireCustomerData: true })'), /Customer logo public link.*not a web address/);
  ss.getRangeByName('cfg_customer_logo_url').setValue('https://drive.google.com/file/d/1abc/view?usp=sharing');
  assert.throws(() => run('Preflight.run(ss, config, { requireCustomerData: true })'), /Drive share link/);
});

test('Preflight still names a required field that is blank, and the retired ones are no longer demanded', () => {
  const ss = workbook('1.8'); ctx.ss = ss;
  run('Migrations.run(ss)'); run('var config = Config.build(ss);');
  run('Layout.verify = function(){ return {ok:true, problems:[]}; }; CONNECTOR_SHEETS_ORDER = [];');
  ss.getRangeByName('cfg_customer_logo_url').setValue('https://cdn.example.com/logo.png');
  ss.getRangeByName('cfg_analyst_email').setValue('');
  assert.throws(() => run('Preflight.run(ss, config, { requireCustomerData: true })'), /missing in the 1_customer tab: Analyst email address\./);
});

test('Payload._requireArgs: false/0 are values, blank strings are not', () => {
  assert.throws(() => run("Payload.validate({correlationId:'', configJsonFileId:'x', requesterEmail:'e', spreadsheetId:'s'})"), /correlationId/);
  assert.doesNotThrow(() => run("Payload.portalInvite({correlationId:'c', userEmail:'u', spreadsheetId:'s'})"));
  assert.deepStrictEqual(J("Payload.invitations({batchId:'b', analystEmail:'a', spreadsheetId:'s', excludeSupplierRequestIds:[' x ','', 'y']}).exclude_supplier_request_ids"), ['x', 'y']);
});

test('1.9 -> 1.10 stamps dropdowns on Target VMS and Variant count; re-run leaves them as existing', () => {
  const ss = workbook('1.8'); ctx.ss = ss;
  const r = run('Migrations.run(ss)');
  assert.strictEqual(r.ok, true);
  const dvAt = (name) => { const nr = ss.named[name]; return ss.sheets['1_customer'].dv[nr.row + ',' + nr.col]; };
  const vals = (dv) => JSON.parse(JSON.stringify(dv.getCriteriaValues()[0]));
  assert.deepStrictEqual(vals(dvAt('cfg_target_vms')), ['Fieldglass', 'VNDLY', 'Beeline']);
  assert.deepStrictEqual(vals(dvAt('cfg_variant_count')), ['1','2','3','4','5','6','7','8','9','10']);
  assert.strictEqual(dvAt('cfg_variant_count').getAllowInvalid(), false);
  assert.strictEqual(dvAt('cfg_customer_name'), undefined, 'no list on a free-text field');
  const again = J('Customer.ensureValidations(ss)');
  assert.deepStrictEqual(again, { applied: [], existing: ['cfg_target_vms', 'cfg_variant_count'], unresolved: [] });
  // a cleared validation comes back
  ss.getRangeByName('cfg_target_vms').clearDataValidations();
  assert.deepStrictEqual(J('Customer.ensureValidations(ss)').applied, ['cfg_target_vms']);
});

test("Preflight 5b': value outside the list is rejected naming the choices; case is canonicalised; blank is 'required'", () => {
  const ss = workbook('1.8'); ctx.ss = ss;
  run('Migrations.run(ss)'); run('var config = Config.build(ss);');
  run('Layout.verify = function(){ return {ok:true, problems:[]}; }; CONNECTOR_SHEETS_ORDER = [];');
  ss.getRangeByName('cfg_customer_logo_url').setValue('https://cdn.example.com/logo.png');
  ss.getRangeByName('cfg_target_vms').setValue('vndly');
  assert.strictEqual(run('Preflight.run(ss, config, { requireCustomerData: true })').targetVms, 'VNDLY');
  ss.getRangeByName('cfg_target_vms').setValue('SAP Fieldglass');
  assert.throws(() => run('Preflight.run(ss, config, { requireCustomerData: true })'), /"Target VMS" value "SAP Fieldglass".*Fieldglass, VNDLY, Beeline/);
  ss.getRangeByName('cfg_target_vms').setValue('');
  assert.throws(() => run('Preflight.run(ss, config, { requireCustomerData: true })'), /missing in the 1_customer tab: Target VMS\./);
  ss.getRangeByName('cfg_target_vms').setValue('Beeline');
  ss.getRangeByName('cfg_variant_count').setValue('12');
  assert.throws(() => run('Preflight.run(ss, config, { requireCustomerData: true })'), /"Variant count" value "12".*1, 2, 3/);
  ss.getRangeByName('cfg_variant_count').setValue(' 3 ');
  assert.strictEqual(run('Preflight.run(ss, config, { requireCustomerData: true })').variantCount, 3);
  ss.getRangeByName('cfg_variant_count').setValue('');
  assert.throws(() => run('Preflight.run(ss, config, { requireCustomerData: true })'), /missing in the 1_customer tab: Variant count\./);
});

console.log('\n' + passed + ' scenario(s) passed');
