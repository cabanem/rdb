// Loads every lib_sdc file into one scope (as Apps Script does), on top of a small in-memory Sheets mock that
// models the pieces the migration chain, Customer, Preflight and Payload touch: cells, deleteRow / insertRowAfter
// with named-range shifting, number formats, data validation, and the _developer_settings tab.
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const LIB = process.argv[2] || require('path').join(__dirname, '..');

// ---------------------------------------------------------------- mock Sheets
class Sheet {
  constructor(ss, name, rows) {
    this.ss = ss; this.name = name;
    this.rows = rows.map(r => r.slice());            // array of arrays, values only
    this.fmt = {}; this.dv = {};                      // "r,c" -> format / validation
  }
  getName() { return this.name; }
  _ensure(r, c) {
    while (this.rows.length < r) this.rows.push([]);
    for (const row of this.rows) while (row.length < c) row.push('');
  }
  getLastRow() {
    for (let i = this.rows.length - 1; i >= 0; i--) {
      if (this.rows[i].some(v => v !== '' && v !== null && v !== undefined)) return i + 1;
    }
    return 0;
  }
  getLastColumn() { return Math.max(1, ...this.rows.map(r => r.length)); }
  getRange(r, c, nr = 1, nc = 1) { this._ensure(r + nr - 1, c + nc - 1); return new Range(this, r, c, nr, nc); }
  getDataRange() { const lr = Math.max(1, this.getLastRow()); return this.getRange(1, 1, lr, this.getLastColumn()); }
  appendRow(vals) { const r = this.getLastRow() + 1; this.getRange(r, 1, 1, vals.length).setValues([vals]); }
  deleteRow(r) {
    this.rows.splice(r - 1, 1);
    for (const [name, nr] of Object.entries(this.ss.named)) {
      if (nr.sheet !== this) continue;
      if (nr.row === r) nr.broken = true;
      else if (nr.row > r) nr.row -= 1;
    }
    this._shiftMeta(r, -1);
  }
  insertRowAfter(r) {
    this.rows.splice(r, 0, new Array(this.getLastColumn()).fill(''));
    for (const nr of Object.values(this.ss.named)) if (nr.sheet === this && nr.row > r) nr.row += 1;
    this._shiftMeta(r + 1, +1);
  }
  _shiftMeta(from, delta) {
    for (const key of ['fmt', 'dv']) {
      const out = {};
      for (const [k, v] of Object.entries(this[key])) {
        let [rr, cc] = k.split(',').map(Number);
        if (delta < 0 && rr === from) continue;
        if (rr >= from) rr += delta;
        out[rr + ',' + cc] = v;
      }
      this[key] = out;
    }
  }
}
class Range {
  constructor(sheet, r, c, nr, nc) { Object.assign(this, { sheet, r, c, nr, nc }); }
  getSheet() { return this.sheet; }
  getRow() { return this.r; }
  getColumn() { return this.c; }
  getValue() { return this.sheet.rows[this.r - 1][this.c - 1]; }
  getValues() {
    const out = [];
    for (let i = 0; i < this.nr; i++) out.push(this.sheet.rows[this.r - 1 + i].slice(this.c - 1, this.c - 1 + this.nc));
    return out;
  }
  setValue(v) {
    // Sheets coerces numeric-looking strings on write unless the cell is plain-text formatted.
    const key = this.r + ',' + this.c;
    if (typeof v === 'string' && this.sheet.fmt[key] !== '@' && /^\s*-?\d+(\.\d+)?\s*$/.test(v)) v = Number(v);
    this.sheet.rows[this.r - 1][this.c - 1] = v; return this;
  }
  setValues(vals) { for (let i = 0; i < vals.length; i++) for (let j = 0; j < vals[i].length; j++) this.sheet.getRange(this.r + i, this.c + j).setValue(vals[i][j]); return this; }
  clearContent() { for (let i = 0; i < this.nr; i++) for (let j = 0; j < this.nc; j++) this.sheet.rows[this.r - 1 + i][this.c - 1 + j] = ''; return this; }
  clearDataValidations() { delete this.sheet.dv[this.r + ',' + this.c]; return this; }
  getDataValidation() { return this.sheet.dv[this.r + ',' + this.c] || null; }
  setDataValidation(d) { this.sheet.dv[this.r + ',' + this.c] = d; return this; }
  setNumberFormat(f) { this.sheet.fmt[this.r + ',' + this.c] = f; return this; }
}
class Spreadsheet {
  constructor(sheets) { this.sheets = {}; this.named = {}; for (const [n, rows] of Object.entries(sheets)) this.sheets[n] = new Sheet(this, n, rows); }
  getId() { return 'SS_FIXTURE'; }
  getSpreadsheetTimeZone() { return 'America/New_York'; }
  getSheetByName(n) { return this.sheets[n] || null; }
  getRangeByName(n) {
    const nr = this.named[n]; if (!nr) return null;
    if (nr.broken) { const rg = new Range(nr.sheet, 0, 0, 1, 1); rg.getValue = () => { throw new Error('#REF!'); }; return rg; }
    return new Range(nr.sheet, nr.row, nr.col, 1, 1);
  }
  setNamedRange(n, range) { this.named[n] = { sheet: range.sheet, row: range.r, col: range.c }; }
  removeNamedRange(n) { if (!this.named[n]) throw new Error('no such range'); delete this.named[n]; }
}

class DataValidationBuilder {
  constructor() { this.kind = null; this.values = []; this.allowInvalid = true; this.help = ''; }
  requireDate() { this.kind = 'DATE_IS_VALID_DATE'; return this; }
  requireValueInList(list, show) { this.kind = 'VALUE_IN_LIST'; this.values = [list.slice(), !!show]; return this; }
  setAllowInvalid(b) { this.allowInvalid = b; return this; }
  setHelpText(t) { this.help = t; return this; }
  build() { const b = this; return { getCriteriaType: () => b.kind, getCriteriaValues: () => b.values, getAllowInvalid: () => b.allowInvalid, getHelpText: () => b.help }; }
}
const SpreadsheetApp = {
  newDataValidation: () => new DataValidationBuilder(),
  DataValidationCriteria: { VALUE_IN_LIST: 'VALUE_IN_LIST', DATE_IS_VALID_DATE: 'DATE_IS_VALID_DATE' }
};
const Utilities = {
  getUuid: () => 'uuid-' + Math.random().toString(16).slice(2),
  formatDate: (d, tz, fmt) => d.toISOString().slice(0, 10),
  sleep: () => {},
  newBlob: (c, t, n) => ({ c, t, n }),
  computeDigest: () => [],
  DigestAlgorithm: { SHA_256: 1 },
  Charset: { UTF_8: 1 }
};
const Session = { getActiveUser: () => ({ getEmail: () => 'emily@example.com' }), getEffectiveUser: () => ({ getEmail: () => 'emily@example.com' }) };
const PropertiesService = { getScriptProperties: () => ({ getProperty: () => '' }), getUserProperties: () => ({ getProperty: () => '', setProperty() {} }), getDocumentProperties: () => ({ getProperty: () => '', setProperty() {} }) };
const DriveApp = {};
const UrlFetchApp = {};
const CacheService = { getScriptCache: () => ({ get: () => null, put() {} }) };
const LockService = { getDocumentLock: () => ({ tryLock: () => true, releaseLock() {} }) };

// ---------------------------------------------------------------- load the library
const ctx = { console, SpreadsheetApp, Utilities, Session, PropertiesService, DriveApp, UrlFetchApp, CacheService, LockService, JSON, Object, Array, Number, String, Boolean, Date, Math, RegExp, Error, parseInt, parseFloat, isNaN, isFinite, encodeURIComponent };
vm.createContext(ctx);
const files = fs.readdirSync(LIB).filter(f => f.endsWith('.js')).sort();
for (const f of files) vm.runInContext(fs.readFileSync(path.join(LIB, f), 'utf8').replace(/\r\n/g, '\n'), ctx, { filename: f });

// Silence sheet logging: Log.forCorrelation writes to _script_logs; we just collect.
ctx.LOGS = [];
vm.runInContext('Log.forCorrelation = function(){ return function(st,msg){ LOGS.push(st+": "+msg); }; };', ctx);

module.exports = { ctx, Spreadsheet, Sheet, Range };
