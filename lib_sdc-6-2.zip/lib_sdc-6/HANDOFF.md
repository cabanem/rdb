# lib_sdc 1.11.0 — schema 1.10 / payload 12.0

1_customer converges on the seven implementation attributes:

| # | Label | key | named range | type | options | wire (provision) |
|---|-------|-----|-------------|------|---------|------------------|
| 1 | Customer name | clientName | cfg_customer_name | string | — | client_name |
| 2 | Analyst email address | analystEmail | cfg_analyst_email | string | — | analyst_email |
| 3 | Target VMS | targetVms | cfg_target_vms | string | Fieldglass / VNDLY / Beeline | target_vms |
| 4 | Reminder cadence | reminderDays | cfg_reminder_days | intList | — | reminder_days (int[]) |
| 5 | Expected completion date | expectedDate | cfg_expected_date | date | — | expected_date (yyyy-MM-dd) |
| 6 | Variant count | variantCount | cfg_variant_count | int | 1..10 | — (consumed by Variant.serializeAll → template_file_ids) |
| 7 | Customer logo public link | customerLogoUrl | cfg_customer_logo_url | string | — | customer_logo_url |

All seven are **required** at provision. Required-ness is the `required` flag on the entry in `003_Schema.js`
CUSTOMER_FIELDS and nowhere else; pick lists are the `options` property on the same entry. Three consumers read
`options`: the migration stamps the Sheets dropdown (`Customer.ensureValidations`, idempotent, also safe from onOpen),
Preflight 5b' rejects anything outside the list and canonicalises case ("vndly" → "VNDLY"), and the web app should
render a `<select>` (see below).

Note on Variant count: before 1.10, blank/0 meant "base template only, no variant files". With a required 1..10 list,
every implementation now produces at least one variant JSON (Variant_1 from 6_variants column G). If a single-template
implementation must stay expressible, make VARIANT_COUNT_OPTIONS start at 0 — one line in 003_Schema.js.

Removed: Application name (cfg_application_name / application_name), Drive folder ID (cfg_output_folder_id /
output_drive_folder_id), Last day for data submission (cfg_last_day_for_submission / last_day_for_submission).

## Regressions repaired in the 1.10.0 archive
- 003_Payload.js was a copy of 005_Preflight.js; `Payload` did not exist. Rebuilt (see the file header for which
  keys are confirmed and which are reconstructed from call sites).
- 005_Provision.js was pre-1.9 (seed-XLSX export stage, nine retired args). Now 12.0.
- 005_Preflight.js carried dead seed checks 5f/5g referencing retired Labels. Removed; 5d is now the logo-link check.
- 002_Migrations.js 1.7→1.8 referenced `seedToken` without defining it (ReferenceError). Defined.
- Migrations._stampSchemaVersion now writes the version as plain text: '1.10' in an automatic-format cell becomes
  the number 1.1. When stamping BASE / master_config by hand, enter `'1.10` (leading apostrophe).

## Outside the library
- app_sdc-shim: `resultDetails_` prints `d.applicationName` — change to `d.clientName`. Delete `debugCustomerSheet()`
  or point it at a surviving field. Grep the shim for applicationName / lastDay / outputDriveFolderId / seedData.
- app_sdc-router (web app): `010_CustomerFields.js` GROUPS/HINTS name retired keys; they filter against the registry
  so nothing breaks, but tidy them and give customerLogoUrl a hint ("direct https:// link to the image file").
  Pick lists: in `toForm(d)` pass `options: d.options ? d.options.map(String) : null` through, and in Index.html's
  field renderer emit `<select>` with one `<option>` per entry (plus an empty first option) when `f.options` is set,
  instead of the text/number input. Everything else (required asterisk, label, key) already comes from the registry.
- BASE / master_config: run "Migrate workbook schema" on it, or hand-edit the rows and stamp meta.schema_version 1.10 as text.
- Workato (do this FIRST — 12.0 removes fields, so a 1.11.0 workbook fails at API-00 until the recipe tolerates it):
  API-00 trigger body schema (drop application_name, output_drive_folder_id, last_day_for_submission; add
  customer_logo_url optional), Functional core connector `customer_required_attributes`, any recipe reading
  `parsed_config.customer.<key>` or the `_customer` block, the Project table columns, and whatever consumed
  output_drive_folder_id (where supplier templates were written). Version-gate on payload_version during cutover.

## Tests
`cd tests && node test.js` — mock Sheets runtime; 10 scenarios (chain 1.8→1.10, idempotency, label fallback,
text stamp, registry reads, preflight, payload shape). `.claspignore` keeps tests/ out of the push.
